package flow_Controls;

public class Switch1 {

	public static void main(String[] args) {
		int a=10;
		switch(a){
		case 10: System.out.println("1st statement");
				break;
		case 20: System.out.println("2nd statement");
				break;
		
		}

	}

}
