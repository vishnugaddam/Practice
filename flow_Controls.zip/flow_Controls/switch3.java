package flow_Controls;

public class switch3 {

	public static void main(String[] args) {
		// it is possible to provide expressions
		int a=99;
		switch(a+1){
		case 10+20+70: System.out.println("1st statement");
						break;
		case 10+5: System.out.println("2nd statement");
					break;
		
		}

	}

}
