package flow_Controls;

public class For2 {

	public static void main(String[] args) {
		
		//Inside the for loop initialization part is optional.
	//int i=0;
		/*for (;i<10;i++)
		{ System.out.println("xeno");
		}*/
		
		
		// more than one initialization is not possible
		/*for (int i = 0,double d=10.8; i < 10; i++) {
			
		}*/
		
		//conditional part is optional, 
		/*for(int i=0;;i++){
			System.out.println("vishnu");
		}
		*/
		//increment/decrement is optional
	/*	for(int i=0;i<10;){
			System.out.println("vishnu");*/
		
		
		//declaring two variables are possible.
		/*for (int i=0,j=0;i<10;i++)
		{ System.out.println("Enterprise");
		}*/
		}
		
		}}
	


