package flow_Controls;

public class For1 {

	public static void main(String[] args) {
		//With out for loop
	
/*		 System.out.println("xtglobal");
		System.out.println("xtglobal");
		System.out.println("xtglobal");
		System.out.println("xtglobal");
		System.out.println("xtglobal");*/
		
	
		//By using for loop
		 for (int i=0;i<5;i++)
			 
		{ System.out.println("xtglobal");

}}}
