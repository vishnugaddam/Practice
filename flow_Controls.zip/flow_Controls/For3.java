package flow_Controls;

public class For3 {

	public static void main(String[] args) {
		//In the initialization part it is possible to take any number of sop statements and each and every statement is separated by comma(,)
		int i=0;
		for (System.out.println("xeno"), System.out.println("soft");i<10;i++)
		{ System.out.println("technologies");
		}

	}

}
