package flow_Controls;

import java.util.ArrayList;

public class For_Each1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> str=new ArrayList<String>();

str.add("vishnu");
str.add("vardhan");
for(String s:str){
	System.out.println(s);
	
}
	

/*ArrayList<String> list=new ArrayList<String>();
	
	list.add("vishnu");
	list.add("vardhan");
	 for(int i=0;i<list.size();i++){
		System.out.println(list.get(i));
	 } 
*/
}
}