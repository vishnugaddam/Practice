package flow_Controls;

import java.util.ArrayList;

public class For_Each {
int a=10;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[]a={10,20,30,40,50};
	
	for(int str:a){
		System.out.println(str);
	}

	
}}
