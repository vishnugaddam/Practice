package flow_Controls;

public class Switch9 {

	public static void main(String[] args) {
		// inside the switch independent statements are not allowed.
		//If we are declaring the statements that statement must be inside the case or default.
		int x=10;
		switch(x)
		{ System.out.println("Hello World");
		}
	}

}
