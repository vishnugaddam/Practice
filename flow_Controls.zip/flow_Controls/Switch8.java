package flow_Controls;

public class Switch8 {

	public static void main(String[] args) {
		// inside the switch both cases and default Is optional
		int a=10;
		switch(a)
		{
		}
	}

}
