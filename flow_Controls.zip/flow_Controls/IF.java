package flow_Controls;

public class IF {

	public static void main(String[] args) {
	int age=20;
	if(age>20){
		System.out.println("if statement");
	}
	System.out.println("after if");

	}

}
