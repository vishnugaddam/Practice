package flow_Controls;

public class Switch12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=97;
		
		switch(97){
		case a: System.out.println("a");
		break;
		
		}

	}

}
