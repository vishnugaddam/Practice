package flow_Controls;

public class IfElse {
//it is possible to provide boolean values
	public static void main(String[] args) {
		if(false){			
			System.out.println("if body");	
		//System.out.println("if body2");
		}
		else{
			System.out.println("else body");
		}}
	/*int  a=20;
	if(a=10){
		System.out.println("true");
	}
	else{
		System.out.println("false");
	}*/
	
	
}
