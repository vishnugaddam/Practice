package flow_Controls;

public class Do_While {

	public static void main(String[] args) {
		int i=1;
		do{
			System.out.println("vishnu");
			i++;
		}while(i<=10);

	}

}
