package flow_Controls;

public class Switch7 {

	public static void main(String[] args) {
		// Inside the switch, cases are optional part.
		int a=10;
		switch (a)
		{ default: System.out.println("default"); break;
		}
	}

}
