package flow_Controls;

public class If1 {

	public static void main(String[] args) {
		// nested if: if statement inside another if statement, inner if block will execute only 
		
		 int age=25;
		 int weight=70;
			if( age<18  ){ 
		           System.out.println("your age is 18+"); 
		           if(weight >50){
			      System.out.println("your eligible for donate blood");
			   }
				   
			   }			
				
			}

	}


