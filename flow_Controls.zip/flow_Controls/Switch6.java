package flow_Controls;

public class Switch6 {

	public static void main(String[] args) {
		//inside the switch the default is optional.
		 int a=10;
		switch (a)
		{ case 20:System.out.println("10"); break;
		}
		

	}

}
