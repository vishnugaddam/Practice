package flow_Controls;

public class Break2 {

	public static void main(String[] args) {
		//if we are using break outside the switch or loop the complier will raise compilation error
		if(true){
			System.out.println("vishnu");
			break;
			System.out.println("vardhan");
		}

	}

}
