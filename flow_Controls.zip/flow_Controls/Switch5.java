package flow_Controls;

public class Switch5 {

	public static void main(String[] args) {
		// inside the switch case label must match with provided argument data type
		char ch='a';
		switch(ch){
		//case "aaa": System.out.println("aaa");
		case 'a': System.out.println("a");
		
		}

	}

}
