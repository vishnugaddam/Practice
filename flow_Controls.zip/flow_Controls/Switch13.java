package flow_Controls;

public class Switch13 {

	public static void main(String[] args) {
		// inside the switch we are able to declare the default statement at starting or middle or end of the switch.
		int a=100;
		switch (a)
		{ 
		case 100:System.out.println("10");
				break;
		case 20:System.out.println("20");
		default: System.out.println("default");
		break;
		}
	}

}
